namespace LeBataillon.Database.Models
{
    public enum PlayerLevel
    { 
        novice,
        débutant,
        intermédiaire,
        avancé
        
    }
}